#!/bin/bin/env bash
#
umask 022
mv posts/posts.json posts/posts.json.backup
python3 build.python.py
